import { Component } from '@angular/core';

@Component({
  selector: 'app-top-nav',
  templateUrl: './top-nav.component.html',
  styleUrls: ['./top-nav.component.css']
})
export class TopNavComponent {
  user1: string | null = '';

  logout() : void{
    if (this.user1 != null) {
      localStorage.removeItem('user1');
    }
  
  }

  ngOnInit(): void {
    // Retrieve the 'user' value from local storage
    this.user1 = localStorage.getItem('user1');
  }
}
