import { Component, EventEmitter, Output } from '@angular/core';
import { Router } from '@angular/router';
import { SearchBarService } from 'src/app/services/searchbar.service';

@Component({
  selector: 'app-top-unav',
  templateUrl: './top-unav.component.html',
  styleUrls: ['./top-unav.component.css']
})
export class TopUnavComponent {
  user1: string | null = '';

  logout() : void{
    if (this.user1 != null) {
      localStorage.removeItem('user1');
    }
  
  }

  ngOnInit(): void {
    // Retrieve the 'user' value from local storage
    this.user1 = localStorage.getItem('user1');
  }
}
