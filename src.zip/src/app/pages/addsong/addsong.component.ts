import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { NodeutilityService } from 'src/app/nodeutility.service';
import { MusicService } from 'src/app/services/music.service';
@Component({
  selector: 'app-addsong',
  templateUrl: './addsong.component.html',
  styleUrls: ['./addsong.component.css']
})
export class AddsongComponent {
  constructor(private util:NodeutilityService,private router:Router,private music:MusicService) { }
  msg: string = '';
  songName:string='';
  singer:string='';
  album:string='';
  selectedFile: File | undefined; 
  selectedFilePath: string | undefined;// Define selectedFile property
  onFileSelected(event: any) {
    const file: File = event.target.files[0];
    this.selectedFile = file;
    this.selectedFilePath = URL.createObjectURL(file);
  }
  onSubmit(form: any) {
    // Ensure that the restaurantimage field is correctly populated
    if (!this.validateForm()) {
      return; // Stop form submission if validation fails
    }
    if (!this.selectedFile) {
      console.error('No file selected.');
      this.msg = 'Upload a song.';
      return; // Stop form submission if no file selected
    }
  
    const formData = new FormData();
    if (this.selectedFilePath) { 
      formData.append('songName', form.value.songname);
      formData.append('singer', form.value.singer);
      formData.append('album', form.value.album);
      formData.append('songlink',this.selectedFile);// Add null check
     
    }
  
    const songData = {
      name: form.value.songname,
      singer: form.value.singer,
      album: form.value.album,
      src: form.value.songlink
    };
  
    this.util.up(formData).subscribe((data) => {
      if (data.status) {
        this.msg = data.message;
        this.music.addSong(songData); // Add the song object, not formData
        console.log('Song added:', songData); // Log the added song data
        alert(this.msg);
      } else {
        this.msg = data.message;
        alert(this.msg);
      }
    });
  }
validateForm(): boolean {

  const fileInput = <HTMLInputElement>document.querySelector('#songlink');
  let song: File | null = null;
  if (fileInput.files && fileInput.files.length > 0) {
    song = fileInput.files[0]; // Get the first file selected (assuming single file upload)
    // Proceed with further processing...
  } else {
    // Handle case where no file is selected
    console.error('No file selected.');
    this.msg = 'Upload a song.';
    alert("Please select a file");
    return false;
  }
 

  // Basic validation example, you can add more specific validations
  if ( !song || !confirm) {
    this.msg = 'Please select a song.';
    return false;
  }
  return true; // Form is valid
}
}

